<?php
 	$db_hostname = "localhost";
 	$db_user = "root";
 	$db_database = "sessionpractical";

?>
