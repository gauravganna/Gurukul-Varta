
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 
<form action="addAuthorbackend.php" method="post" enctype="multipart/form-data">
	Enter Author Name :
	<input type="text" name="authorName">
	<br><br>
	Enter Author-Designation :
	<input type="text" name="authorDesignation">
	<br><br>
	Give Image of Author :
	<input type="file" name="img" id="img">
	<br><br>
	<input type="Submit" name="submit" value="Submit">
</form>

</body>
</html>